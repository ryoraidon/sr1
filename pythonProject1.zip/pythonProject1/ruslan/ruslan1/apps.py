from django.apps import AppConfig


class Ruslan1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ruslan1'
